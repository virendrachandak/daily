(function() {
    var S = KISSY;
    var UA = S.UA;
    var TPL = ['<div class="mid-wraper" draggable="false">',
                    '<div class="mid-caiban mid-hide"></div>',
                    '<div class="mid-wendu-wraper mid-hide">',
                        '<div class="mid-wendu"></div>',
                    '</div>',
                    '<div class="mid-mianpi mid-mianpi1 mid-hide"></div>',
                    '<div class="mid-mianzhang mid-hide"></div>',
                    '<div class="mid-xianliao-center mid-hide">',
                        '<div class="mid-xianliao mid-xianliao1"></div>',
                        '<div class="mid-xianliao mid-xianliao2"></div>',
                        '<div class="mid-xianliao mid-xianliao3"></div>',
                        '<div class="mid-xianliao mid-xianliao4"></div>',
                        '<div class="mid-xianliao mid-xianliao5"></div>',
                        '<div class="mid-xianliao mid-xianliao6"></div>',
                        '<div class="mid-xianliao mid-xianliao7"></div>',
                    '</div>',
                    '<div class="mid-wan mid-hide">',
                        '<div class="mid-wan-a mid-wan-type1"></div>',
                        '<div class="mid-wan-a mid-wan-type2"></div>',
                        '<div class="mid-wan-a mid-wan-type3"></div>',
                    '</div>',
                    '<div class="mid-shaozi mid-hide"></div>',
                    '<div class="mid-step3">',
                        '<div class="mid-bao mid-hide"></div>',
                        '<div class="mid-zhedie-center mid-hide"></div>',
                        '<div class="mid-virtual mid-hide"></div>',
                        '<div class="mid-yindao mid-hide">',
                            '<div class="mid-line"></div>',
                        '</div>',
                    '</div>',
                    '<div class="mid-quan mid-hide"></div>',
                    '<div class="mid-shou mid-shou1 mid-hide"></div>',
                    '<div class="mid-step5 mid-hide">',
                        '<div class="mid-die-center"></div>',
                        '<div class="mid-tuan"></div>',
                        '<div class="mid-xiaoguo"></div>',
                        '<div class="mid-die"></div>',
                    '</div>',
                    '<div class="mid-step6 mid-hide">',
                        '<div class="mid-kaoxiang"></div>',
                        '<div class="mid-switch-btn mid-switch-on"></div>',
                        '<div class="mid-huo-wraper">',
                            '<div class="mid-huo"></div>',
                        '</div>',
                    '</div>',
                    '<div class="mid-state mid-hide"></div>',
                    '<div class="mid-end mid-hide"></div>',
                    '<div class="mid-spread mid-hide">',
                        '<div class="mid-link mid-hide"><input class="mid-input" value=""></div>',
                        '<div class="mid-share-friend"></div>',
                        '<a class="mid-share-weibo" href=""></a>',
                        '<div class="mid-again"></div>',
                    '</div>',
                    '<div class="mid-text"></div>',
                    '<div class="mid-gz"></div>',
                    '<div class="mid-result"></div>',
                    '<div class="mid-dao mid-hide"></div>',
                    '<div class="mid-star mid-star-title1">',
                        '<div class="mid-star-bg"></div>',
                        '<div class="mid-title"></div>',
                    '</div>',
                    '<div class="mid-start">',
                        '<div class="mid-start-btn"></div>',
                    '</div>',
                '</div>',
                '<div class="mid-close-btn"></div>'].join('');
    
    function SendLog(args){
        (window.goldlog_queue || (window.goldlog_queue = [])).push({
          action   : 'goldlog.emit',
          arguments: ["tb_index_logo", args]
        }); 
        /*
            args:
            a=1 打开游戏
            a=2 开始游戏
            a=3 完成游戏
        */
    };


    S.use('node',function(S,NODE){
        var $ = NODE.all;

        function Game(){
            this.WENDUDEFAULT = 193; // 温度计高度
            this.HUOHOUDEFAULT = 246; // 火候高度
            this.SHARETEXT = '@淘公仔官方 #和你一起做月饼#，我刚在淘宝首页做了一个{{name}}月饼，请各位亲笑纳！祝亲们，中秋愉快，好事圆圆，好梦连连！点击{{link}}，赶紧来尝鲜下吧！ ';
            this.RESULT = {
                TYPE112: ['T1M2mZFiJbXXa6XtY7','没烤熟的','http://gtms03.alicdn.com/tps/i3/T13NKZFfXcXXbSpW2X-772-379.gif'], // 完美生星星
                TYPE113: ['T1TEGYFfxbXXa6XtY7','完美的','http://gtms04.alicdn.com/tps/i4/T1.39VFjxgXXbSpW2X-772-379.gif'], // 完美熟星星
                TYPE114: ['T1SSuYFa4cXXa6XtY7','烤糊的','http://gtms01.alicdn.com/tps/i1/T1bf5UFmFgXXbSpW2X-772-379.gif'], // 完美糊星星
                TYPE122: ['T1lXeYFoFcXXa6XtY7','没烤熟的','http://gtms02.alicdn.com/tps/i2/T1MWy1Ff8XXXbSpW2X-772-379.gif'], // 完美生彩虹
                TYPE123: ['T1E.CWFitcXXa6XtY7','完美的','http://gtms03.alicdn.com/tps/i3/T1b71SFepgXXbSpW2X-772-379.gif'], // 完美熟彩虹
                TYPE124: ['T1OY1YFaVdXXa6XtY7','烤糊的','http://gtms04.alicdn.com/tps/i4/T1mM5IFk0hXXbSpW2X-772-379.gif'], // 完美糊彩虹
                TYPE132: ['T1XomZFihXXXa6XtY7','没烤熟的','http://gtms01.alicdn.com/tps/i1/T1ueOYFldeXXbSpW2X-772-379.gif'], // 完美生爱心
                TYPE133: ['T1jhWYFbRcXXa6XtY7','完美的','http://gtms02.alicdn.com/tps/i2/T1kySJFj8hXXbSpW2X-772-379.gif'], // 完美熟爱心
                TYPE134: ['T1iw1YFepcXXa6XtY7','烤糊的','http://gtms03.alicdn.com/tps/i3/T1uX5YFnXeXXbSpW2X-772-379.gif'], // 完美糊爱心
                TYPE212: ['T1E_mVFgNcXXa6XtY7','没烤熟的','http://gtms04.alicdn.com/tps/i4/T1ty1WFf8eXXbSpW2X-772-379.gif'], // 缺陷生星星
                TYPE213: ['T1xkSUFkxfXXa6XtY7','完美的','http://gtms02.alicdn.com/tps/i2/T1HC10FeXaXXbSpW2X-772-379.gif'], // 缺陷熟星星
                TYPE214: ['T1SzWWFcteXXa6XtY7','烤糊的','http://gtms03.alicdn.com/tps/i3/T1XO9TFi8gXXbSpW2X-772-379.gif'], // 缺陷糊星星
                TYPE222: ['T1aVKYFjtbXXa6XtY7','没烤熟的','http://gtms04.alicdn.com/tps/i4/T1hKCWFdVfXXbSpW2X-772-379.gif'], // 缺陷生彩虹
                TYPE223: ['T1PXWZFXtbXXa6XtY7','完美的','http://gtms01.alicdn.com/tps/i1/T1J9OVFoleXXbSpW2X-772-379.gif'], // 缺陷熟彩虹
                TYPE224: ['T1AvCWFjtcXXa6XtY7','烤糊的','http://gtms02.alicdn.com/tps/i2/T1SBmZFXpcXXbSpW2X-772-379.gif'], // 缺陷糊彩虹
                TYPE232: ['T1zo9VFcNfXXa6XtY7','没烤熟的','http://gtms03.alicdn.com/tps/i3/T1gGOWFbNeXXbSpW2X-772-379.gif'], // 缺陷生爱心
                TYPE233: ['T1DxWVFdJfXXa6XtY7','完美的','http://gtms04.alicdn.com/tps/i4/T1iBeYFmXcXXbSpW2X-772-379.gif'], // 缺陷熟爱心
                TYPE234: ['T1VOqVFhhgXXa6XtY7','烤糊的','http://gtms01.alicdn.com/tps/i1/T1_EOTFnlgXXbSpW2X-772-379.gif'], // 缺陷糊爱心
            };
            this.init();
        };
        S.augment(Game,{
            init: function(){
                this._initLogo();
            },
            _initLogo: function(){
                var self = this;
                var logo_container = $('#J_LayoutHd .logo');
                var new_logo = $('<div class="midAutumn-logo"><i></i></div>');
                if(TB&&TB.Global&&TB.Global.version=='2.0'){
                    logo_container = $('#J_Search').next('.logo');
                    logo_container.css('position','relative');
                };
                this._initStage(function(){
                    logo_container.append(new_logo);
                    new_logo.on('click', function(){
                        self.open();
                    });
                });
            },
            _initStage:function(callback){
                var self = this;
                self.stage = $('<div id="midAutumnGame"><div class="mid-container"></div></div>');
                self.container = self.stage.one('.mid-container');

                $('body').prepend(self.stage);

                if(S.UA.ie&&S.UA.ie<9){
                    callback&&callback();
                    this._initGame();
                }else{
                    this._initGame(callback);
                }
            },
            _initGame:function(callback){
                var self = this;
                self._initContainer();
                self._initVariable();
                self._initEvent();
                self._loadImg('http://gtms01.alicdn.com/tps/i1/T1VCOWFgVfXXbfoH_l-250-100.gif',callback);
            },
            _loadImg: function(url,callback){
                var self = this;
                var img = new Image();
                img.onload = function(){
                    callback&&callback();
                };
                img.src = url;
            },
            _initContainer: function(){
                var self = this;
                self.container.html(TPL);
                self.dom = {
                    closeBtn: self.stage.one('.mid-close-btn'),
                    startBtn: self.stage.one('.mid-start-btn'),
                    switchBtn: self.stage.one('.mid-switch-btn'),
                    xianliaoCenter: self.stage.one('.mid-xianliao-center'),
                    zhedieCenter: self.stage.one('.mid-zhedie-center'),
                    dieCenter: self.stage.one('.mid-die-center'),
                    wraper: self.stage.one('.mid-wraper'),
                    star: self.stage.one('.mid-star'),
                    mianpi: self.stage.one('.mid-mianpi'),
                    caiban: self.stage.one('.mid-caiban'),
                    mianzhang: self.stage.one('.mid-mianzhang'),
                    wenduWraper: self.stage.one('.mid-wendu-wraper'),
                    huoWraper: self.stage.one('.mid-huo-wraper'),
                    wendu: self.stage.one('.mid-wendu'),
                    midtext: self.stage.one('.mid-text'),
                    gz: self.stage.one('.mid-gz'),
                    wan: self.stage.one('.mid-wan'),
                    shaozi: self.stage.one('.mid-shaozi'),
                    yindao: self.stage.one('.mid-yindao'),
                    virtual: self.stage.one('.mid-virtual'),
                    step3Div: self.stage.one('.mid-step3'),
                    step5Div: self.stage.one('.mid-step5'),
                    step6Div: self.stage.one('.mid-step6'),
                    shou: self.stage.one('.mid-shou'),
                    quan: self.stage.one('.mid-quan'),
                    die: self.stage.one('.mid-die'),
                    tuan: self.stage.one('.mid-tuan'),
                    bao: self.stage.one('.mid-bao'),
                    xiaoguo: self.stage.one('.mid-xiaoguo'),
                    huo: self.stage.one('.mid-huo'),
                    kaoxiang: self.stage.one('.mid-kaoxiang'),
                    result: self.stage.one('.mid-result'),
                    spread: self.stage.one('.mid-spread'),
                    end: self.stage.one('.mid-end'),
                    link: self.stage.one('.mid-link'),
                    linkInput: self.stage.one('.mid-input'),
                    shareWeibo: self.stage.one('.mid-share-weibo'),
                    shareFriend: self.stage.one('.mid-share-friend'),
                    dao: self.stage.one('.mid-dao'),
                    state: self.stage.one('.mid-state')
                };
            },
            _initVariable: function(){
                var self = this;
                self.variable = {
                    zhedienum: null,
                    ganmian: null,
                    roumian: null,
                    cutMooncake: null,
                    gamestate: null,
                    gamestep: null,
                    gamenum: null,
                    huohou: null,
                    isSelected: null,
                    hasXiaoliao: null,
                    virtualShow: null,
                    mooncakeOut: 1, // 月饼外观 1:完美 2:缺陷
                    mooncakeIn: 1, // 月饼馅料 1:星星 2:彩虹 3:爱心
                    mooncakeResult: 1 // 月饼结果 1:原料 2:糊 3:生 4:熟
                };
            },
            _initEvent: function(){
                var self = this;
                // 关闭游戏
                self.dom.closeBtn.on('click',function(){
                    self.close();
                });
                // 开始游戏
                self.dom.wraper.delegate('click','.mid-start-btn',function(){
                    self.start();
                });
                // 选择馅料
                self.dom.wraper.delegate('click','.mid-shaozi',function(e){
                    self._xianliao(e);
                });
                // 包月饼
                self.dom.wraper.delegate('mousedown','.mid-yindao',function(e){
                    self.dom.virtual.css('z-index','999');
                    self.variable.virtualShow = true;
                });
                // 模具
                self.dom.wraper.delegate('click','.mid-die',function(e){
                    self._downDie(e);
                });
                // 开关
                self.dom.wraper.delegate('click','.mid-switch-btn',function(){
                    if (self.dom.switchBtn.hasClass('mid-switch-on')) {
                        self._complete();
                    };
                });
                // 擀面
                self.dom.wraper.delegate('mousedown','.mid-mianzhang',function(e){
                    self.dom.mianzhang.addClass('mid-mianzhang-down');
                    self.variable.ganmian = true;
                });
                self.dom.wraper.delegate('mouseup','.mid-mianzhang',function(){
                    self.dom.mianzhang.removeClass('mid-mianzhang-down');
                    self.variable.ganmian = false;
                });
                // 揉月饼
                self.dom.wraper.delegate('mousedown','.mid-shou',function(){
                    self.dom.shou.addClass('mid-shou2');
                    self.variable.roumian = true;
                });
                self.dom.wraper.delegate('mouseup','.mid-shou',function(){
                    self.dom.shou.removeClass('mid-shou2');
                    self.variable.roumian = false;
                });
                // 切月饼
                self.dom.wraper.delegate('mousedown','.mid-dao',function(e){
                    self.dom.dao.addClass('mid-dao-down');
                    self.variable.cutMooncake = true;
                    self._cut(e);
                });
                self.dom.wraper.delegate('mouseup','.mid-dao',function(){
                    self.dom.dao.removeClass('mid-dao-down');
                    self.variable.cutMooncake = false;
                });
                // 最后一步
                self.dom.wraper.delegate('click','.mid-result',function(){
                    self.step7();
                });
                // 分享给朋友
                self.dom.wraper.delegate('mouseover','.mid-share-friend',function(){
                    self._shareFriend();
                });
                self.dom.wraper.delegate('click','.mid-input',function(e){
                   e.currentTarget.select();
                });
                // 再做一个
                self.dom.wraper.delegate('click','.mid-again',function(){
                    self._initGame();
                });
                // 工具移动
                self.dom.wraper.on('mousemove',function(e){
                    var offsetX = offsetY = 20;
                    if (self.variable.gamestep == 'step1') {
                        offsetX = self.dom.mianzhang.width()/2;
                        offsetY = self.dom.mianzhang.height()/2;
                        self._move(e,self.dom.mianzhang,offsetX,offsetY,function(){
                            self._mianzhang(e);
                        });
                    };
                    if (self.variable.gamestep == 'step2') {
                        self._move(e,self.dom.shaozi,offsetX,offsetY,function(){
                        });
                    };
                    if (self.variable.gamestep == 'step4') {
                        offsetX = self.dom.shou.width()/2;
                        offsetY = self.dom.shou.height()/2;
                        self._move(e,self.dom.shou,offsetX,offsetY,function(){
                            self._quan(e);
                        });
                    };
                    if (self.variable.gamestep == 'step5') {
                        self._move(e,self.dom.die,70,105,function(){
                        });
                    };
                    if (self.variable.gamestep == 'step7') {
                        self._move(e,self.dom.dao,127,95,function(){
                        });
                    };
                    if (self.variable.virtualShow) {
                        self._move(e,self.dom.virtual,12,12,function(){
                        });
                    };
                });
                self.dom.wraper.on('mouseup',function(e){
                    self.dom.virtual.css('z-index','');
                    self.variable.virtualShow = false;
                    self._yindaoUp(e);
                });
            },
            _quan: function(e){
                var self = this;
                var x = e.pageX;
                var y = e.pageY;
                self._checkPos(x,y,self.dom.quan,function(){
                    if (self.variable.roumian) {
                        self._wendu(function(w){
                            if (w >= 1) {
                                self.step5()
                            };
                        });
                    };
                });
            },
            _mianzhang: function(e){
                var self = this;
                var x = e.pageX;
                var y = e.pageY;
                self._checkPos(x,y,self.dom.mianpi,function(){
                    if (self.variable.ganmian) {
                        self._wendu(function(w){
                            if (w >= .3 && w <= .6) {
                                self.dom.mianpi.attr('class','mid-mianpi mid-mianpi2');
                            };
                            if (w >= .6 && w < 1) {
                                self.dom.mianpi.attr('class','mid-mianpi mid-mianpi3');
                            };
                            if (w >= 1) {
                                self.dom.mianpi.attr('class','mid-mianpi mid-mianpi4');
                                self.step2()
                            };
                        });
                    };
                });
            },
            _xianliao: function(e){
                /* 馅料选择 */
                var self = this;
                var x = e.pageX;
                var y = e.pageY;
                var target = $(e.target);
                var t1 = self.stage.one('.mid-wan-type1');
                var t2 = self.stage.one('.mid-wan-type2');
                var t3 = self.stage.one('.mid-wan-type3');
                function selectXiaoliao(d,t){
                    self.variable.mooncakeIn = t;
                    self.variable.hasXiaoliao = true;
                    self.dom.shaozi.attr('class','mid-shaozi mid-shaozi'+self.variable.mooncakeIn);
                    if(self.variable.isSelected){return};
                    self.variable.isSelected = true;
                    t1.addClass('mid-hide');
                    t2.addClass('mid-hide');
                    t3.addClass('mid-hide');
                    d.removeClass('mid-hide').animate({"top":118},1,"easeOutStrong",function(){
                    });
                };
                self._checkPos(x,y,t1,function(){
                    selectXiaoliao(t1,1);
                });
                self._checkPos(x,y,t2,function(){
                    selectXiaoliao(t2,2);
                });
                self._checkPos(x,y,t3,function(){
                    selectXiaoliao(t3,3);
                });
                self._checkPos(x,y,self.dom.xianliaoCenter,function(){
                    if(!self.variable.hasXiaoliao){return};
                    self.variable.hasXiaoliao = false;
                    var xianliao = self.dom.xianliaoCenter.all('.mid-xianliao');
                    self.dom.shaozi.attr('class','mid-shaozi');
                    xianliao.each(function(d,k){
                        if (d.attr('class').indexOf('mid-xianliao-type')==-1) {
                            k++;
                            d.addClass('mid-xianliao-type'+self.variable.mooncakeIn);
                            if (k == xianliao.length) {
                                self.step3();
                            };
                            return false;
                        };
                    });
                });
            },
            _downDie: function(e){
                var self = this;
                var tuanX = self.dom.tuan.offset().left;
                var tuanY = self.dom.tuan.offset().top;
                var x = e.pageX;
                var y = e.pageY;
                var minX1 = tuanX + 30;
                var minY1 = tuanY + 22;
                var maxX1 = tuanX + 70;
                var maxY1 = tuanY + 60;
                var minX2 = tuanX - 80;
                var minY2 = tuanY - 180;
                var maxX2 = tuanX + 160;
                var maxY2 = tuanY + 180;
                var isOK = false;
                if (x >= minX1 && x <= maxX1 && y >= minY1 && y <= maxY1) {
                    isOK = true;
                    self.variable.mooncakeOut = 1;
                }else if(x >= minX2 && x <= maxX2 && y >= minY2 && y <= maxY2){
                    isOK = true;
                    self.variable.mooncakeOut = 2;
                };
                self.dom.die.addClass('mid-die2');
                if (!isOK) {
                    setTimeout(function(){
                        self.dom.die.removeClass('mid-die2');
                    },300);
                    return;
                };
                self._hide('tuan','dieCenter','die');
                self.dom.xiaoguo.addClass('mid-xiaoguo'+self.variable.mooncakeOut);
                setTimeout(function(){
                    self.step6();
                },1000);
            },
            _yindaoUp: function(e){
                var self = this;
                var x = e.pageX;
                var y = e.pageY;
                self.dom.virtual.css({
                    top: '',
                    left: ''
                });
                self._checkPos(x,y,self.dom.zhedieCenter,function(){
                    var num = self.variable.zhedienum;
                    num = num ? num+1:1;
                    self.variable.zhedienum = num;
                    self.dom.yindao.attr('class','mid-yindao mid-yindao-step'+num);
                    self.dom.step3Div.attr('class','mid-step3 mid-bao-step'+num);
                    if (num == 5) {
                        self.step4();
                    };
                });
            },
            _huohou: function(){
                var self = this;
                self.huoTime = setInterval(function(){
                    self.variable.huohou = self.variable.huohou ? self.variable.huohou - 23 : self.HUOHOUDEFAULT - 23;
                    self.variable.huohou = self.variable.huohou > 0 ? self.variable.huohou : 0;
                    self.dom.huo.height(self.variable.huohou);
                    var h = self.HUOHOUDEFAULT-self.variable.huohou;
                    if (h > 184) {
                        self.variable.mooncakeResult = 4;
                    };
                    if (h == 184) {
                        self.variable.mooncakeResult = 3;
                    };
                    if (h < 184) {
                        self.variable.mooncakeResult = 2;
                    };
                    if (h >= 246) {
                        self._complete();
                    };
                },500);
            },
            _complete: function(){
                var self = this;
                var r = self.variable.mooncakeOut+'-'+self.variable.mooncakeResult;
                var targetSize = {
                        width: '226px',
                        height: '226px',
                        left: '300px',
                        top: '80px'
                    };
                var targetCallBack = function(){
                        self.step7();
                    };
                var mooncake = self.RESULT['TYPE'+self.variable.mooncakeOut+self.variable.mooncakeIn+self.variable.mooncakeResult];
                self._loadImg(mooncake[2]);
                console.log(mooncake[2])
                clearInterval(self.huoTime);
                self.dom.switchBtn.removeClass('mid-switch-on');
                self.dom.kaoxiang.addClass('mid-kaoxiang-off');
                if(UA.ie&&UA.ie<9){
                    self.dom.result.addClass('mid-result-'+r).css(targetSize);
                    setTimeout(targetCallBack,1000);
                } else{
                    self.dom.result.addClass('mid-result-'+r).animate(targetSize,1,'easeOutStrong',targetCallBack);
                };
            },
            _cut: function(e){
                var self = this;
                self._checkPos(e.pageX,e.pageY,self.dom.result,function(){
                    self.step8();
                });
            },
            _shareFriend: function(){
                var self = this;
                self._show('link');
            },
            _checkPos: function(x,y,d,callback){
                var self = this;
                var dx = d.offset().left;
                var dy = d.offset().top;
                var dxMax = dx + d.width();
                var dyMax = dy + d.height();
                if (x>=dx && y>=dy && x<=dxMax && y<=dyMax) {
                    callback&&callback();
                };
            },
            _wendu: function(callback){
                var self = this;
                self.wenduHeight = self.wenduHeight ? self.wenduHeight-1 : self.WENDUDEFAULT - 1;
                var percent = (1-self.wenduHeight/self.WENDUDEFAULT).toFixed(2);
                self.dom.wendu.height(self.wenduHeight);
                callback&&callback(percent);
            },
            _episode: function(t,callback){
                /* 过渡动画 */
                var self = this;
                self.dom.gz.addClass('mid-gz2');
                self.dom.star
                    .attr('class','mid-star mid-star-title'+t)
                    .animate({"opacity":1},1.5,"easeOutStrong",function(){
                        self.dom.star.animate({"opacity":0},.5,"easeOutStrong",function(){
                            self._hide('star');
                            self.dom.gz.removeClass('mid-gz2');
                            callback&&callback();
                        });
                });
            },
            _move: function(e,dom,offsetX,offsetY,callback){
                var self = this;
                var x = e.pageX;
                var y = e.pageY;
                offsetX = offsetX || 0;
                offsetY = offsetY || 0;
                var left = x - self.dom.wraper.offset().left - offsetX;
                var top = y - self.dom.wraper.offset().top - offsetY;
                dom.css({
                    top: top,
                    left: left
                });
                callback&&callback();
            },
            _show: function(){
                var self = this;
                var arr = arguments;
                S.each(arr, function(item) {
                    self.dom[item].removeClass('mid-hide');
                });
            },
            _hide: function(){
                var self = this;
                var arr = arguments;
                S.each(arr, function(item) {
                    self.dom[item].addClass('mid-hide');
                });
            },
            _makeUrl: function(type){
                var self = this;
                var mooncake = self.RESULT['TYPE'+self.variable.mooncakeOut+self.variable.mooncakeIn+self.variable.mooncakeResult];
                var mooncakeLink = mooncake&&mooncake[0]||"";
                var mooncakeName = mooncake&&mooncake[1]||"";
                if (type == 'weibo') {
                    var text = self.SHARETEXT.replace('{{name}}',mooncakeName).replace('{{link}}','http://www.taobao.com/?mc='+ mooncakeLink);
                    var pic = 'http://gtms01.alicdn.com/tps/i1/'+ mooncakeLink +'-490-170.png';
                    return 'http://service.weibo.com/share/share.php?title='+encodeURIComponent(text)+'&pic='+encodeURIComponent(pic);
                } else {
                    return 'http://www.taobao.com/?mc='+ mooncakeLink;
                };
            },
            open: function(){
                var self = this;
                if (self.variable.gamestate) {return};
                if (self.variable.gamenum) {self._initGame();};
                self.stage.show().animate({"height":420},1,"easeOutStrong",function(){
                    self.variable.gamestate = true;
                });
                SendLog({a: 1});
            },
            close: function(){
                var self = this;
                self.stage.animate({"height":0},1,"easeOutStrong",function(){
                    self.variable.gamestate = false;
                });
            },
            start: function(){
                var self = this;
                self.variable.gamenum += 1;
                self.variable.gamestep = 'step1';
                self.dom.star.animate({"opacity":0},.5,"easeOutStrong",function(){
                    self._hide('star');
                });
                self.dom.startBtn.animate({"top":600},.3,"easeOutStrong",function(){
                    self.step1();
                });
                SendLog({a: 2});
            },
            step1: function(){
                var self = this;
                self.dom.midtext.attr('class','mid-text mid-text1');
                self._show('caiban','wenduWraper','mianpi','mianzhang');
            },
            step2: function(){
                var self = this;
                self.variable.gamestep = 'step2';
                self._hide('wenduWraper','mianzhang');
                self.dom.wendu.height('');
                self._episode(2,function(){
                    self.dom.midtext.attr('class','mid-text mid-text2');
                    self._show('xianliaoCenter','wan','shaozi');
                });
            },
            step3: function(){
                var self = this;
                self.variable.gamestep = 'step3';
                self._hide('wan','shaozi');
                self.dom.bao.addClass('.mid-bao-type'+self.variable.mooncakeIn);
                self._episode(2,function(){
                    self.dom.midtext.attr('class','mid-text mid-text3');
                    self._hide('mianpi','xianliaoCenter');
                    self._show('bao','zhedieCenter','yindao','virtual');
                });
            },
            step4: function(){
                var self = this;
                self.variable.gamestep = 'step4';
                self._hide('zhedieCenter','yindao','virtual');
                self._episode(2,function(){ 
                    self.dom.midtext.attr('class','mid-text mid-text4');
                    self._show('wenduWraper','quan','shou');
                });
            },
            step5: function(){
                var self = this;
                self.variable.gamestep = 'step5';
                self._hide('wenduWraper','shou','quan','bao');
                self._episode(2,function(){
                    self.dom.midtext.attr('class','mid-text mid-text5');
                    self._show('step5Div');
                });
            },
            step6: function(){
                var self = this;
                self.variable.gamestep = 'step6';
                self._episode(2,function(){
                    self.dom.midtext.attr('class','mid-text mid-text6');
                    self._hide('caiban','die','xiaoguo');
                    self._show('step6Div');
                    self._huohou();
                });
            },
            step7: function(){
                var self = this;
                var opacity = function(){
                    var arr = arguments;
                    S.each(arr, function(item) {
                        self.dom[item].animate({"opacity":0},1,"easeOutStrong",function(){});
                    });                    
                };
                self.variable.gamestep = 'step7';
                self._episode(2,function(){
                    opacity('kaoxiang','switchBtn','huoWraper','star');
                    self._show('dao','state');
                    self.dom.midtext.attr('class','mid-text mid-text7');
                    self.dom.state.addClass('mid-state-'+self.variable.mooncakeOut+'-'+self.variable.mooncakeResult);
                });
            },
            step8: function(){
                var self = this;
                var targetSize = {
                        width: '113px',
                        height: '113px',
                        left: '329px',
                        top: '63px'
                    };
                var targetCallBack = function(){
                        self._hide('result');
                        self._show('end');
                        self.dom.end.addClass('mid-end-'+self.variable.mooncakeOut+'-'+self.variable.mooncakeIn+'-'+self.variable.mooncakeResult);
                        setTimeout(function(){self._show('spread');},200);
                        SendLog({a: 3});
                    };
                self.variable.gamestep = 'step8';
                self.dom.shareWeibo.attr('href',self._makeUrl('weibo'));
                self.dom.linkInput.val(self._makeUrl('friend'));
                self._hide('dao','gz','midtext','state');
                if(UA.ie&&UA.ie<9){
                    targetCallBack();
                }else{
                    self.dom.result.animate(targetSize,1,"easeOutStrong",targetCallBack);
                };
            }
        });

        try{
            if (FP.load) {
                new Game();
            } else {
                $(window).on('load',function(){
                    new Game();
                });
            };
        }catch(e){};
    });

})();