<?php

/**
 * created by bachi@taobao.com
 * modified by yunqian@taobao.com
 */

// set pre as default CDN
$CDN = 'http://110.75.14.33/';
$CDN = 'http://10.232.16.2/';
//$CDN = 'http://assets.taobaocdn.com/';

$refCDN = explode('__cdn__=', $_SERVER['HTTP_REFERER']);
$forceCDN = $refCDN[1];
if (empty($forceCDN)) {
	/*
    if ($_SERVER['HTTP_HOST'] == 'assets.daily.taobao.net') {
        $forceCDN = 'daily';
    }
    if ($_SERVER['HTTP_HOST'] == 'a.tbcdn.cn') {
        $forceCDN = 'online';
    }
    */
}

// for quick set
// $forceCDN = 'pre';
// $forceCDN = 'daily';

if ($forceCDN == 'daily') {
    $CDN = 'http://10.232.16.2/';
} else if ($forceCDN == 'pre') {
    $CDN = 'http://110.75.14.33/';
} else if ($forceCDN == 'online') {
    $CDN = 'http://a.tbcdn.cn/';
}

// ???
function get_contents($url){
    $ch =curl_init($url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $str =curl_exec($ch);
    curl_close($ch);
    if ($str !==false) {
        return $str;
    }else {
        return '';
    }
}

// ??
function get_extend($file_name) {
    $file_name = explode("?t=", $file_name);
	$extend =explode("." , $file_name[0]);
	$va=count($extend)-1;
	return $extend[$va];
}

/**
 * begin
 */

//cdn�ϴ��ڵĸ��ֿ��ܵ��ļ�����
$header = array(
    'js' => 'Content-Type: application/x-javascript',
    'css' => 'Content-Type: text/css',
    'jpg' => 'Content-Type: image/jpg',
    'gif' => 'Content-Type: image/gif',
    'png' => 'Content-Type: image/png',
    'jpeg' => 'Content-Type: image/jpeg',
    'swf' => 'Content-Type: application/x-shockwave-flash'
);

//�ļ�����
$type = '';
//�ļ�����·������
$files = array();
// ?��
$tmp_files = array();

// ??
$prefix = $_SERVER['SCRIPT_NAME'];
$url = $_SERVER['REQUEST_URI'];
// $url = str_replace('apps/taesite/platform/build/20121119/stylesheets/platform/ctt-manage/items-classify-min.css', 'apps/platinum/src/stylesheet/??platform/common/framework.css,platform/common/navbar.css,platform/common/newtoolbar.css,platform/common/dialog.css,platform/common/sidebar.css,platform/ctt-manage/base.css,platform/ctt-manage/icon-tips.css,platform/ctt-manage/items-classify/base.css,platform/ctt-manage/items-classify/item-list.css,platform/ctt-manage/items-classify/item-opts.css,platform/ctt-manage/items-classify/pagination.css,platform/ctt-manage/items-classify/calendar.css', $url);
$url = str_replace('apps/taesite/platinum/stylesheet/platform/ctt-manage/items-classify-min.css', 'apps/platinum/src/stylesheet/??platform/common/framework.css,platform/common/navbar.css,platform/common/newtoolbar.css,platform/common/dialog.css,platform/common/sidebar.css,platform/ctt-manage/base.css,platform/ctt-manage/icon-tips.css,platform/ctt-manage/items-classify/base.css,platform/ctt-manage/items-classify/item-list.css,platform/ctt-manage/items-classify/item-opts.css,platform/ctt-manage/items-classify/pagination.css,platform/ctt-manage/items-classify/calendar.css', $url);
$url = str_replace('apps/taesite/platinum/stylesheet/ctt-manage/cats-manage-min.css', 'apps/platinum/src/stylesheet/??platform/common/wangpubarnew.css,platform/common/newtoolbar.css,platform/common/sidebar.css,platform/ctt-manage/base.css,platform/ctt-manage/cats-tree.css,platform/ctt-manage/icon-tips.css,platform/ctt-manage/cats-manage/cat-opts.css,platform/ctt-manage/cats-manage/cat-edit.css,platform/ctt-manage/cats-manage/dialog.css,platform/ctt-manage/cats-manage/scroll.css,view/global/footer.css', $url);
$split_a= explode("??",$url);
$tmp_files = explode(",",$split_a[1]);

if (preg_match('/,/',$split_a[1])) {//?
	$prefix = $split_a[0];
	$_tmp = explode(',',$split_a[1]);
	foreach($_tmp as $v){
		$files[] = $prefix.$v;
	}
} else {//?
	$files[] = $prefix.$split_a[1];
}

$R_files = array();

foreach ($files as $k) {
	$k = preg_replace(
		array('/^\//','/\?.+$/'),
		array('',''),
		$k);

	if (!preg_match('/(\.js|\.css|\.png|\.gif|\.jpg|\.jpeg)$/', $k)) {
		continue;
	}
    if(empty($type)) {
		$type = get_extend($k);
	}

	//$k = str_replace('switchable-min.js', 'switchable.js', $k);
	//$k = str_replace('global-min.js', 'global.js', $k);
	$k = str_replace('header-top-min.js', 'header-top.js', $k);
	$k = str_replace('detail-min.js', 'detail.js', $k);

  // TAESite Scripts.
  // if (strpos($k, ".css") == false && strpos($k, "apps/taesite/platform/") > -1) {
  //   $k = str_replace('apps/taesite/platform/build/20121119/', 'apps/platinum/src/', $k);
  //   $k = str_replace('-min', '', $k);
  // }
	if (strpos($k, ".css") == false && strpos($k, "apps/taesite/platinum/scripts") > -1) {
		$k = str_replace('apps/taesite/platinum/scripts', 'apps/platinum/src/scripts', $k);
		$k = str_replace('-min', '', $k);
	}
	//�ļ�����
    if ($forceCDN == '' && file_exists($k)) {
		$R_files[] = file_get_contents($k);
    } else {
		//�ļ�������
			try {
            if ($type == 'css' || $type == 'js') {
			    $R_files[] = '/***** ('.$forceCDN.') '.$CDN.$k.' *****/';
			    $R_files[] = join('', file($CDN.$k));
            } else {
                $R_files[] = file_get_contents($CDN.$k);
            }
		} catch (Exception $e) {}
    }
}


date_default_timezone_set ('Asia/Shanghai');

//���ӹ���ͷ
// header("Expires: " . date("D, j M Y H:i:s", strtotime("now + 10 years")) ." GMT");
header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header('Pragma: no-cache');
// header('Content-Type: text/html; charset=utf-8'); 

//�ļ�����
header($header[$type]);

//ƴװ�ļ�
$result = join("\n", $R_files);

//����ļ�
echo $result;

?>